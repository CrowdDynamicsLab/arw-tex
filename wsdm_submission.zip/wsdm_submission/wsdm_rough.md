

#### Theoretical Justification

> We note that a theoretical analysis is hard, connect to pagerank. We note that dataset bias, connect to methods to eliminate fringe nodes

A mathematical analysis of the model appears to lead to difficult theoretical questions about random walks on directed graphs. Unlike the case of undirected graphs, there is no analytical closed form expression for stationary distributions of random walks on *general* directed graph.



-----

